import time
import board
import digitalio
import usb_hid
from adafruit_hid.keycode import Keycode
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

cc = ConsumerControl(usb_hid.devices)

keyboard = Keyboard(usb_hid.devices)

write_text = KeyboardLayoutUS(keyboard)

buttons = [board.GP0, board.GP1,board.GP2,board.GP3,board.GP4,board.GP5,board.GP6,board.GP7,board.GP8,board.GP9,board.GP10,board.GP11]
key = [digitalio.DigitalInOut(pin_name) for pin_name in buttons]
for x in range(0,len(buttons)):
    key[x].direction = digitalio.Direction.INPUT
    key[x].pull = digitalio.Pull.DOWN



while True:
    
    if key[0].value:
        print("button 1")
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)
        time.sleep(0.1)
        
    if key[1].value:
        print("button 2")
        cc.send(ConsumerControlCode.VOLUME_DECREMENT)
        time.sleep(0.1)
        
    if key[2].value:
        print("button 3")
        cc.send(ConsumerControlCode.PLAY_PAUSE)
        time.sleep(0.1)
        
    if key[3].value:
        print("button 4")
        cc.send(ConsumerControlCode.MUTE)
        time.sleep(0.1)
        
    if key[4].value:
        print("button 5")
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)
        time.sleep(0.1)
        
    if key[5].value:
        print("button 6")
        file = open("typer.txt", "r")
        contents = file.read()
        time.sleep(0.1)
        write_text.write(contents)
        file.close()